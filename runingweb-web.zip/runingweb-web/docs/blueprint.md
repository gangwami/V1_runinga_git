# **App Name**: StreamView

## Core Features:

- Stream Display: Display HLS stream from a given URL.
- Stream Selection: Allow users to select from a list of predefined HLS stream URLs.
- Playback Controls: Provide basic playback controls (play, pause, volume).

## Style Guidelines:

- Mobile-first, responsive design.
- Primary color: Dark gray (#333) for the background to provide a cinematic feel.
- Accent: Teal (#008080) for interactive elements.
- Full-screen video playback option.
- Simple, clean icons for playback controls.