
import type { Stream } from "@/types";

export const initialStreamsData: Stream[] = [
  {
    id: "stream1",
    name: "conq tv",
    sourceUrls: [
        "https://runinga.co.ke:1938/live/conq.m3u8",
        "https://runinga.co.ke:1938/live/conq1.m3u8",
        "https://runinga.co.ke:1938/live/conq2.m3u8"
    ],
    description: "Live broadcast from Conq TV.",
    views: 1234,
  },
   {
    id: "stream3",
    name: "Imani TV",
    sourceUrls: [
        "https://runinga.co.ke:1938/live/imani1.m3u8",
        "https://runinga.co.ke:1938/live/imani2.m3u8",
        "https://runinga.co.ke:1938/live/imani3.m3u8"
    ],
    description: "Faith-based programming on Imani TV.",
    views: 2468,
  },
  {
    id: "stream2",
    name: "Elimu TV",
    sourceUrls: [
        "https://runinga.co.ke:1938/live/test.m3u8",
        "https://runinga.co.ke:1938/live/test1.m3u8",
        "https://runinga.co.ke:1938/live/test2.m3u8"
    ],
    description: "Educational content from Elimu TV.",
    views: 5678,
  },
  {
    id: "stream4",
    name: "Big Buck Bunny (Apple)",
    sourceUrls: [
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8",
        "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
        "https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8"
    ],
    description: "A classic short film by the Blender Institute, provided by Apple.",
    views: 9876,
  },
  {
    id: "stream5",
    name: "mutha-TV",
    sourceUrls: [
        "https://runinga.co.ke:1938/live/test.m3u8",
        "https://runinga.co.ke:1938/live/test_backup1.m3u8",
        "https://runinga.co.ke:1938/live/test_backup2.m3u8"
    ],
    description: "SRT stream from mutha-TV, converted to HLS for playback.",
    views: 345,
  },
  {
    id: "stream7",
    name: "NIce tv",
    sourceUrls: [
        "https://runinga.co.ke:1938/live/nicetv.m3u8",
        "https://runinga.co.ke:1938/live/nicetv1.m3u8",
        "https://runinga.co.ke:1938/live/nicetv2.m3u8"
    ],
    description: "Live stream from NIce tv.",
    views: 0,
  }
];
