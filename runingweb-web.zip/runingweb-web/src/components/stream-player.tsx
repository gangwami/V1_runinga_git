
// @ts-nocheck
"use client";

import type { ComponentProps } from "react";
import Hls from "hls.js";
import { useEffect, useRef, useState } from "react";
import { Maximize, Minimize, Pause, Play, Volume1, Volume2, VolumeX, WifiOff } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type VideoPlayerProps = {
  src: string[];
  autoPlay?: boolean;
  onActiveSourceChanged?: (activeUrl: string | null) => void;
};

export function HlsPlayer({ src: sourceUrls, autoPlay = false, onActiveSourceChanged }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const [currentSourceIndex, setCurrentSourceIndex] = useState(0);
  const [activeSrc, setActiveSrc] = useState<string | null>(null);


  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;

    let currentHlsInstanceForSetup: Hls | null = null;

    const tryLoadSource = (index: number) => {
      if (index >= sourceUrls.length) {
        console.error("All sources failed to load.");
        setIsOffline(true);
        setActiveSrc(null);
        if (onActiveSourceChanged) onActiveSourceChanged(null);
        if (hlsRef.current) {
            hlsRef.current.destroy();
            hlsRef.current = null;
        }
        return;
      }

      const currentSrc = sourceUrls[index];
      setActiveSrc(currentSrc);
      console.log(`Attempting to load source: ${currentSrc} (index: ${index})`);
      setIsOffline(false); 

      if (Hls.isSupported()) {
        if (hlsRef.current) {
          hlsRef.current.destroy();
          hlsRef.current = null;
        }

        const hlsConfig = {
          maxBufferLength: 180, 
          maxMaxBufferLength: 300,
        };
        currentHlsInstanceForSetup = new Hls(hlsConfig);
        hlsRef.current = currentHlsInstanceForSetup;

        currentHlsInstanceForSetup.loadSource(currentSrc);
        currentHlsInstanceForSetup.attachMedia(videoElement);

        currentHlsInstanceForSetup.on(Hls.Events.MANIFEST_PARSED, () => {
          console.log(`Manifest parsed for source: ${currentSrc}`);
          setIsOffline(false);
          setCurrentSourceIndex(index);
          if (onActiveSourceChanged) onActiveSourceChanged(currentSrc);
          if (autoPlay) {
            videoElement.play().catch(error => {
              if (error.name === 'NotAllowedError') {
                console.warn("Autoplay was prevented by the browser.");
                setIsPlaying(false);
              } else if (error.name !== 'AbortError') {
                console.error("Error auto-playing video:", error);
              }
            });
            setIsPlaying(true);
          }
        });

        currentHlsInstanceForSetup.on(Hls.Events.ERROR, (event, data) => {
          console.error(`HLS.js error for source ${currentSrc}:`, data);
          
          let criticalErrorForSourceSwitch = false;

          if (!data || Object.keys(data).length === 0) {
            criticalErrorForSourceSwitch = true;
            console.warn(`HLS.js provided sparse error data for ${currentSrc}. Assuming critical failure for this source.`);
          } else {
            if (data.fatal) {
              criticalErrorForSourceSwitch = true;
            } else if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              criticalErrorForSourceSwitch = true;
            } else if (
              data.details === Hls.ErrorDetails.MANIFEST_LOAD_ERROR ||
              data.details === Hls.ErrorDetails.MANIFEST_LOAD_TIMEOUT ||
              data.details === Hls.ErrorDetails.LEVEL_LOAD_ERROR ||
              data.details === Hls.ErrorDetails.LEVEL_LOAD_TIMEOUT ||
              data.details === Hls.ErrorDetails.MANIFEST_PARSING_ERROR
            ) {
              criticalErrorForSourceSwitch = true;
            }
          }

          if (criticalErrorForSourceSwitch) {
            console.warn(`Critical HLS error on ${currentSrc} (Type: ${data?.type}, Details: ${data?.details}, Fatal: ${data?.fatal}). Attempting next source.`);
            
            const instanceBeingDestroyed = currentHlsInstanceForSetup;
            if (instanceBeingDestroyed) {
                 if (videoElement && instanceBeingDestroyed.media === videoElement) {
                    instanceBeingDestroyed.detachMedia();
                }
                instanceBeingDestroyed.destroy();
                if (hlsRef.current === instanceBeingDestroyed) {
                    hlsRef.current = null;
                }
            }
            currentHlsInstanceForSetup = null; 
            tryLoadSource(index + 1);
          } else {
            console.warn(`Non-critical HLS error on ${currentSrc} (Type: ${data?.type}, Details: ${data?.details}). HLS.js may attempt recovery.`);
          }
        });

      } else if (videoElement.canPlayType('application/vnd.apple.mpegurl')) {
        videoElement.src = currentSrc;
        const onNativeError = () => {
          console.warn(`Native HLS failed for source ${currentSrc}, trying next...`);
          videoElement.removeEventListener('error', onNativeError);
          videoElement.removeEventListener('loadedmetadata', onNativeSuccess);
          tryLoadSource(index + 1);
        };
        const onNativeSuccess = () => {
          console.log(`Native HLS loaded source: ${currentSrc}`);
          setIsOffline(false);
          setCurrentSourceIndex(index);
          if (onActiveSourceChanged) onActiveSourceChanged(currentSrc);
          videoElement.removeEventListener('error', onNativeError);
          videoElement.removeEventListener('loadedmetadata', onNativeSuccess);
          if (autoPlay) {
            videoElement.play().catch(error => {
              if (error.name === 'NotAllowedError') {
                console.warn("Autoplay was prevented by the browser (native HLS).");
                 setIsPlaying(false);
              } else if (error.name !== 'AbortError') {
                console.error("Error auto-playing native HLS:", error);
              }
            });
            setIsPlaying(true);
          }
        };
        videoElement.addEventListener('error', onNativeError);
        videoElement.addEventListener('loadedmetadata', onNativeSuccess);
        videoElement.load(); 
      } else {
        console.error("HLS is not supported on this browser.");
        setIsOffline(true);
        if (onActiveSourceChanged) onActiveSourceChanged(null);
        return;
      }
    };

    if (sourceUrls && sourceUrls.length > 0) {
      if (onActiveSourceChanged) onActiveSourceChanged(null); // Reset before trying new sources
      tryLoadSource(0); 
    } else {
      console.error("No source URLs provided.");
      setIsOffline(true);
      if (onActiveSourceChanged) onActiveSourceChanged(null);
    }

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
      if (hlsRef.current) {
        if (videoElement && hlsRef.current.media === videoElement) {
            hlsRef.current.detachMedia();
        }
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      currentHlsInstanceForSetup = null; 

      if (videoElement) {
        videoElement.pause();
        videoElement.removeAttribute('src'); 
        videoElement.load(); 
      }
      if (onActiveSourceChanged) {
        onActiveSourceChanged(null);
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceUrls, autoPlay /*removed onActiveSourceChanged from deps to avoid re-triggering on its change*/]); 


  useEffect(() => {
    const video = videoRef.current;
    if (video && activeSrc) { 
      if (isPlaying && !isOffline) {
        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            if (error.name === 'NotAllowedError') {
              console.warn("Playback was prevented by the browser.");
              setIsPlaying(false); 
            } else if (error.name === 'NotSupportedError') {
              console.error("The media format is not supported.", error);
              setIsOffline(true);
            } else if (error.name !== 'AbortError') { 
                 console.error("Error playing video:", error);
            }
          });
        }
      } else {
        video.pause();
      }
    }
  }, [isPlaying, isOffline, activeSrc]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);
  
  useEffect(() => {
    const player = videoRef.current;
    if (!player) return;

    const handleLoadedMetadata = () => setDuration(player.duration);
    const handleTimeUpdate = () => setCurrentTime(player.currentTime);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleVolumeChange = () => {
      if (player) { 
        setVolume(player.volume);
        setIsMuted(player.muted);
      }
    };
    const handleFullScreenChange = () => {
        const doc = document as any; 
        setIsFullScreen(!!(doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement || doc.msFullscreenElement));
    };
    const handleError = (e: Event) => {
        console.error("Video element error:", e);
        if (!hlsRef.current && activeSrc) { 
            console.warn(`General video error for ${activeSrc}. Player might attempt next source if not already.`);
        }
    };

    player.addEventListener("loadedmetadata", handleLoadedMetadata);
    player.addEventListener("timeupdate", handleTimeUpdate);
    player.addEventListener("play", handlePlay);
    player.addEventListener("pause", handlePause);
    player.addEventListener("volumechange", handleVolumeChange);
    player.addEventListener("error", handleError);
    
    document.addEventListener('fullscreenchange', handleFullScreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
    document.addEventListener('mozfullscreenchange', handleFullScreenChange);
    document.addEventListener('MSFullscreenChange', handleFullScreenChange);

    return () => {
      if (player) {
        player.removeEventListener("loadedmetadata", handleLoadedMetadata);
        player.removeEventListener("timeupdate", handleTimeUpdate);
        player.removeEventListener("play", handlePlay);
        player.removeEventListener("pause", handlePause);
        player.removeEventListener("volumechange", handleVolumeChange);
        player.removeEventListener("error", handleError);
      }
      
      document.removeEventListener('fullscreenchange', handleFullScreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullScreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullScreenChange);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeSrc]); 

  const togglePlayPause = () => {
    if (isOffline || !activeSrc) return; 
    setIsPlaying(!isPlaying);
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    setIsMuted(newVolume === 0);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      videoRef.current.muted = newVolume === 0;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      if (!isMuted && volume === 0) { 
        setVolume(0.5);
        videoRef.current.volume = 0.5;
      }
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time) || time === Infinity) return '0:00'; 
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  };
  
  const handleSeek = (value: number[]) => {
    if (videoRef.current && Number.isFinite(duration) && duration > 0 && !isOffline && activeSrc) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const toggleFullScreen = () => {
    const playerContainer = videoRef.current?.closest('.player-container-selector') as HTMLElement & { 
        webkitRequestFullscreen?: () => Promise<void>;
        mozRequestFullScreen?: () => Promise<void>;
        msRequestFullscreen?: () => Promise<void>;
     };

    const doc = document as Document & {
        mozCancelFullScreen?: () => Promise<void>;
        webkitExitFullscreen?: () => Promise<void>;
        msExitFullscreen?: () => Promise<void>;
    };

    if (!playerContainer) return;

    if (!isFullScreen) {
      if (playerContainer.requestFullscreen) {
        playerContainer.requestFullscreen().catch(err => console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`));
      } else if (playerContainer.webkitRequestFullscreen) { 
        playerContainer.webkitRequestFullscreen().catch(err => console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`));
      } else if (playerContainer.mozRequestFullScreen) { 
        playerContainer.mozRequestFullScreen().catch(err => console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`));
      } else if (playerContainer.msRequestFullscreen) { 
        playerContainer.msRequestFullscreen().catch(err => console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`));
      }
    } else {
      if (doc.exitFullscreen) {
        doc.exitFullscreen();
      } else if (doc.webkitExitFullscreen) { 
        doc.webkitExitFullscreen();
      } else if (doc.mozCancelFullScreen) { 
        doc.mozCancelFullScreen();
      } else if (doc.msExitFullscreen) { 
        doc.msExitFullscreen();
      }
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying && !isOffline && activeSrc) { 
        controlsTimeoutRef.current = setTimeout(() => {
            setShowControls(false);
        }, 3000);
    }
  };

  const handleMouseLeave = () => {
    if (isPlaying && !isOffline && activeSrc) { 
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
      controlsTimeoutRef.current = setTimeout(() => setShowControls(false), 500); 
    }
  };
  
  useEffect(() => {
    if (!isPlaying || isOffline || !activeSrc) { 
      setShowControls(true);
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    } else {
      handleMouseMove(); 
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, isOffline, activeSrc]);


  return (
    <div 
        className="relative w-full aspect-video bg-black rounded-lg overflow-hidden shadow-2xl group player-container-selector"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        aria-label="Video player"
        role="application"
    >
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline 
        aria-live={isPlaying ? "off" : "polite"}
      />
      {isOffline && !activeSrc && ( 
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/75 text-white z-10">
            <WifiOff className="w-16 h-16 mb-4 text-destructive" />
            <p className="text-2xl font-semibold">STREAM OFFLINE</p>
            <p className="text-sm text-muted-foreground">All sources failed. Please try again later.</p>
        </div>
      )}
       {isOffline && activeSrc && ( 
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/75 text-white z-10">
            <WifiOff className="w-16 h-16 mb-4 text-destructive" />
            <p className="text-xl font-semibold">CURRENT SOURCE OFFLINE</p>
            <p className="text-sm text-muted-foreground">Attempting other sources or please try again later.</p>
        </div>
      )}
      <div 
        className={cn(
            "absolute inset-0 flex flex-col justify-between p-4 transition-opacity duration-300 ease-in-out z-20", 
            showControls || isOffline || !activeSrc ? "opacity-100" : "opacity-0 group-hover:opacity-100" 
        )}
        aria-hidden={!showControls && !isOffline && !!activeSrc}
      >
        <div></div>

        <div className="flex flex-col gap-2">
            {duration > 0 && Number.isFinite(duration) && !isOffline && activeSrc && (
              <div className="flex items-center gap-2 text-xs text-white">
                  <span aria-label="Current time">{formatTime(currentTime)}</span>
                  <Slider
                    value={[currentTime]}
                    max={duration}
                    step={1}
                    onValueChange={handleSeek}
                    className="w-full cursor-pointer"
                    aria-label="Seek slider"
                    aria-valuetext={`${formatTime(currentTime)} of ${formatTime(duration)}`}
                    disabled={isOffline || !activeSrc}
                  />
                  <span aria-label="Total duration">{formatTime(duration)}</span>
                </div>
            )}

            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={togglePlayPause} 
                        className="text-white hover:bg-white/20 hover:text-white rounded-full"
                        aria-label={isPlaying ? "Pause" : "Play"}
                        disabled={isOffline || !activeSrc}
                    >
                    {isPlaying && !isOffline && activeSrc ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                    </Button>
                
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={toggleMute} 
                        className="text-white hover:bg-white/20 hover:text-white rounded-full"
                        aria-label={isMuted || volume === 0 ? "Unmute" : "Mute"}
                        disabled={isOffline || !activeSrc}
                    >
                    {isMuted || volume === 0 ? <VolumeX className="w-6 h-6" /> : volume < 0.5 ? <Volume1 className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                    </Button>
                
                    <div className="w-24">
                        <Slider
                            value={[isMuted ? 0 : volume]}
                            max={1}
                            step={0.01}
                            onValueChange={handleVolumeChange}
                            className="cursor-pointer"
                            aria-label="Volume slider"
                            aria-valuetext={`${Math.round((isMuted ? 0 : volume) * 100)}%`}
                            disabled={isOffline || !activeSrc}
                        />
                    </div>
                </div>
              
                <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={toggleFullScreen} 
                    className="text-white hover:bg-white/20 hover:text-white rounded-full"
                    aria-label={isFullScreen ? "Exit full screen" : "Enter full screen"}
                    disabled={isOffline || !activeSrc}
                >
                    {isFullScreen ? <Minimize className="w-6 h-6" /> : <Maximize className="w-6 h-6" />}
                </Button>
            </div>
        </div>
      </div>
    </div>
  );
}
