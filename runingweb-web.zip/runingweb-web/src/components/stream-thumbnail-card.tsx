
"use client";

import Image from "next/image";
import type { Stream } from "@/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye } from "lucide-react";

interface StreamThumbnailCardProps {
  stream: Stream;
  onStreamSelect: (stream: Stream) => void;
}

export function StreamThumbnailCard({ stream, onStreamSelect }: StreamThumbnailCardProps) {
  const isActive = true; 

  return (
    <Card
      className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-200 cursor-pointer flex flex-col rounded-lg group h-full bg-card border-border"
      onClick={() => onStreamSelect(stream)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault(); 
          onStreamSelect(stream);
        }
      }}
      aria-label={`Play stream: ${stream.name}`}
    >
      <div className="w-full aspect-video relative overflow-hidden">
        <Image
          src={`https://picsum.photos/seed/${stream.id}/400/225`} 
          alt={`Thumbnail for ${stream.name}`}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover group-hover:scale-105 transition-transform duration-300 ease-in-out"
          data-ai-hint="live stream tv"
          priority={false} 
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
        {isActive && (
          <Badge 
            variant="secondary" 
            className="absolute top-2 right-2 text-xs px-2 py-1 flex items-center gap-1 bg-black/75 text-white border-black/50"
            aria-label={`${stream.views.toLocaleString()} views`}
          >
            <Eye className="w-3 h-3" />
            {stream.views.toLocaleString()}
          </Badge>
        )}
      </div>
      <CardHeader className="p-3 pb-1">
        <CardTitle className="text-base font-semibold text-card-foreground truncate" title={stream.name}>
          {stream.name}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 pt-0 flex-grow">
        {stream.description && (
          <CardDescription className="text-xs text-muted-foreground line-clamp-2 mb-1" title={stream.description}>
            {stream.description}
          </CardDescription>
        )}
      </CardContent>
    </Card>
  );
}

    