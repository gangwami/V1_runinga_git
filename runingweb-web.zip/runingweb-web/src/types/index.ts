
export type Stream = {
  id: string;
  name: string;
  sourceUrls: string[]; // Changed from url: string to sourceUrls: string[]
  description?: string;
  views: number;
  deletedAt?: string; // ISO string for deletion timestamp
  creatorId?: string; // ID of the user who created the stream
};

export type User = {
  id: string; // Typically username for this mock, or a generated ID for social
  username: string;
  role: 'admin' | 'creator';
  method: 'credentials' | 'google' | 'facebook';
  lastLogin: string; // ISO string
};

