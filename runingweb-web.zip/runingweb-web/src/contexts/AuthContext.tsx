
"use client";

import type { ReactNode } from 'react';
import { createContext, useContext, useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import type { User } from '@/types'; // Import the User type

type UserRole = 'admin' | 'creator' | null;

interface AuthContextType {
  isAuthenticated: boolean;
  userRole: UserRole;
  userId: string | null;
  login: (username: string, pass: string) => boolean;
  signInWithGoogle: () => boolean;
  signInWithFacebook: () => boolean;
  signUpCreator: (username: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const MOCK_USERS_KEY = 'mockRegisteredUsers';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedAuth = localStorage.getItem('isAuthenticated');
      const storedRole = localStorage.getItem('userRole') as UserRole;
      const storedUserId = localStorage.getItem('userId');

      if (storedAuth === 'true' && storedRole) {
        setIsAuthenticated(true);
        setUserRole(storedRole);
        setUserId(storedUserId);
      } else if (storedAuth === 'true' && !storedRole) {
        setIsAuthenticated(true);
        setUserRole(null); // Should ideally not happen, but handle gracefully
        setUserId(null);
      }
       else {
        setIsAuthenticated(false);
        setUserRole(null);
        setUserId(null);
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('isAuthenticated', isAuthenticated.toString());
      if (userRole) {
        localStorage.setItem('userRole', userRole);
      } else {
        localStorage.removeItem('userRole');
      }
      if (userId) {
        localStorage.setItem('userId', userId);
      } else {
        localStorage.removeItem('userId');
      }
    }
  }, [isAuthenticated, userRole, userId]);

  const addOrUpdateMockUser = (id: string, username: string, role: 'admin' | 'creator', method: 'credentials' | 'google' | 'facebook') => {
    if (typeof window === 'undefined') return;
    const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
    let users: User[] = [];
    if (usersRaw) {
      try {
        const parsedUsers = JSON.parse(usersRaw);
        if (Array.isArray(parsedUsers)) {
            users = parsedUsers;
        } else {
            console.error("Mock users from localStorage was not an array.");
        }
      } catch (e) {
        console.error("Failed to parse mock users from localStorage", e);
      }
    }
    
    const existingUserIndex = users.findIndex(u => u.id === id || u.username.toLowerCase() === username.toLowerCase());
    const now = new Date().toISOString();

    if (existingUserIndex > -1) {
      users[existingUserIndex].role = role; // Update role if it changed (e.g. admin logs in via social initially)
      users[existingUserIndex].lastLogin = now;
      users[existingUserIndex].method = method; // Update method if it changed
      users[existingUserIndex].username = username; // Ensure username is current
    } else {
      users.push({ id, username, role, method, lastLogin: now });
    }
    localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
  };

  const handleSuccessfulLogin = (loggedInUserId: string, username: string, role: 'admin' | 'creator', method: 'credentials' | 'google' | 'facebook') => {
    setIsAuthenticated(true);
    setUserRole(role);
    setUserId(loggedInUserId);
    addOrUpdateMockUser(loggedInUserId, username, role, method);
    if (role === 'admin') {
      router.push('/admin');
    } else if (role === 'creator') {
      router.push('/user-dashboard');
    }
  };


  const login = (username: string, pass: string): boolean => {
    const lowerUsername = username.toLowerCase();
    const generatedUserId = `cred_${lowerUsername}`; 

    if ((lowerUsername === 'admin' && pass === 'admin') || (lowerUsername === 'maina' && pass === '2025works!!')) {
      handleSuccessfulLogin(generatedUserId, username, 'admin', 'credentials');
      return true;
    }
    if (lowerUsername === 'creator' && pass === 'creator') {
      handleSuccessfulLogin(generatedUserId, username, 'creator', 'credentials');
      return true;
    }
    
    // Check dynamically created users (mock password check - very basic)
    if (typeof window !== 'undefined') {
        const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
        if (usersRaw) {
            try {
                const users: User[] = JSON.parse(usersRaw);
                const foundUser = users.find(u => u.username.toLowerCase() === lowerUsername && u.method === 'credentials');
                // In a real app, you'd hash and compare passwords. Here, we assume if found, password is "correct" for mock.
                if (foundUser) {
                     // For mock, we assume any password works if user was created via signup form.
                    handleSuccessfulLogin(foundUser.id, foundUser.username, foundUser.role as 'creator', 'credentials');
                    return true;
                }
            } catch(e) {
                console.error("Error reading mock users for login", e);
            }
        }
    }
    return false;
  };

  const signUpCreator = async (username: string, pass: string): Promise<{ success: boolean; message?: string }> => {
    if (typeof window === 'undefined') return { success: false, message: "Window not available." };

    const lowerUsername = username.toLowerCase();
    const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
    let users: User[] = [];
    if (usersRaw) {
        try { users = JSON.parse(usersRaw); } catch(e) { /* ignore, start fresh */ }
    }

    // Check if username is one of the special hardcoded ones or already exists
    if (['admin', 'maina', 'creator'].includes(lowerUsername) || users.some(u => u.username.toLowerCase() === lowerUsername)) {
        return { success: false, message: "Username already taken or reserved." };
    }

    const newUserId = `cred_${lowerUsername}_${Date.now().toString().slice(-4)}`;
    // Do not store 'pass' in a real app like this. This is purely for mock.
    handleSuccessfulLogin(newUserId, username, 'creator', 'credentials');
    return { success: true, message: "Account created successfully! Redirecting..." };
  };


  const signInWithGoogle = (): boolean => {
    // For mock, generate a unique-ish username and ID each time for simplicity of demo,
    // or check if a google_user already exists to simulate re-login.
    // For this prototype, we'll always create a new 'creator' or log in as existing based on a generic google ID.
    const googleId = 'mock_google_user_001'; // A fixed ID for demo purposes of re-login
    const googleUsername = 'GoogleUser' + googleId.slice(-3);

    // Check if this mock Google user already exists in mockRegisteredUsers
    const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
    let users: User[] = [];
    if (usersRaw) {
        try { users = JSON.parse(usersRaw); } catch (e) { /* ignore */ }
    }
    const existingUser = users.find(u => u.id === googleId && u.method === 'google');

    if (existingUser) {
        handleSuccessfulLogin(existingUser.id, existingUser.username, 'creator', 'google');
    } else {
        handleSuccessfulLogin(googleId, googleUsername, 'creator', 'google');
    }
    return true;
  };

  const signInWithFacebook = (): boolean => {
    const facebookId = 'mock_facebook_user_001';
    const facebookUsername = 'FacebookUser' + facebookId.slice(-3);

    const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
    let users: User[] = [];
    if (usersRaw) {
        try { users = JSON.parse(usersRaw); } catch (e) { /* ignore */ }
    }
    const existingUser = users.find(u => u.id === facebookId && u.method === 'facebook');
    
    if (existingUser) {
        handleSuccessfulLogin(existingUser.id, existingUser.username, 'creator', 'facebook');
    } else {
        handleSuccessfulLogin(facebookId, facebookUsername, 'creator', 'facebook');
    }
    return true;
  };


  const logout = () => {
    setIsAuthenticated(false);
    setUserRole(null);
    setUserId(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('userRole');
      localStorage.removeItem('userId');
    }
    router.push('/'); // Redirect to home page
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const publicPaths = ['/login', '/'];
      const isCurrentlyAuthenticated = isAuthenticated || localStorage.getItem('isAuthenticated') === 'true';
      const currentRole = userRole || localStorage.getItem('userRole') as UserRole;

      if (!publicPaths.includes(pathname) && !isCurrentlyAuthenticated) {
        router.push('/login');
      } else if (pathname === '/admin' && (!isCurrentlyAuthenticated || currentRole !== 'admin')) {
        if (isCurrentlyAuthenticated && currentRole !== 'admin') router.push('/');
        else if (!isCurrentlyAuthenticated) router.push('/login');
      } else if (pathname === '/user-dashboard' && (!isCurrentlyAuthenticated || (currentRole !== 'creator' && currentRole !== 'admin') )) { // Admin can also access user-dashboard if needed for testing
         if (isCurrentlyAuthenticated && currentRole !== 'creator' && currentRole !== 'admin') router.push('/');
         else if (!isCurrentlyAuthenticated) router.push('/login');
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, userRole, pathname, router]);


  return (
    <AuthContext.Provider value={{ isAuthenticated, userRole, userId, login, signInWithGoogle, signInWithFacebook, signUpCreator, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

