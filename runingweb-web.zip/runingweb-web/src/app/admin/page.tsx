
"use client";

import { useState, useEffect } from "react";
import type { Stream, User } from "@/types"; // Import User type
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input"; // Added Input
import { Label } from "@/components/ui/label"; // Added Label
import { Textarea } from "@/components/ui/textarea"; // Added Textarea
import { CheckCircle, XCircle, ArrowLeft, ShieldCheck, Eye, AlertTriangle, Trash2, History, LogOut, Users, PlusCircle } from "lucide-react"; // Added Users icon and PlusCircle
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { HlsPlayer } from "@/components/stream-player";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";

const PENDING_STREAMS_KEY = 'pendingAdminStreams';
const USER_ADDED_STREAMS_KEY = 'userAddedStreams';
const STREAMS_PENDING_DELETION_KEY = 'streamsPendingDeletion';
const DELETED_STREAMS_HISTORY_KEY = 'deletedStreamsHistory';
const MOCK_USERS_KEY = 'mockRegisteredUsers'; // Key for storing mock users

export default function AdminDashboardPage() {
  const [isClient, setIsClient] = useState(false);
  const [pendingStreams, setPendingStreams] = useState<Stream[]>([]);
  const [approvedStreams, setApprovedStreams] = useState<Stream[]>([]);
  const [streamsPendingDeletion, setStreamsPendingDeletion] = useState<Stream[]>([]);
  const [deletedStreamsHistory, setDeletedStreamsHistory] = useState<Stream[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<User[]>([]); // State for registered users
  const { toast } = useToast();

  const [selectedStreamForPreview, setSelectedStreamForPreview] = useState<Stream | null>(null);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [activePreviewPlayingUrl, setActivePreviewPlayingUrl] = useState<string | null>(null);

  // State for adding a new stream by admin
  const [newStreamName, setNewStreamName] = useState('');
  const [newStreamUrl1, setNewStreamUrl1] = useState('');
  const [newStreamUrl2, setNewStreamUrl2] = useState('');
  const [newStreamUrl3, setNewStreamUrl3] = useState('');
  const [newStreamDescription, setNewStreamDescription] = useState('');
  const [lastSubmittedStreamForPreview, setLastSubmittedStreamForPreview] = useState<Stream | null>(null);
  const [isPreviewSubmittedStreamDialogOpen, setIsPreviewSubmittedStreamDialogOpen] = useState(false);

  const { isAuthenticated, userRole, logout, userId } = useAuth();
  const router = useRouter();

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      if (!isAuthenticated || userRole !== 'admin' || !userId) {
        router.push('/login');
        return;
      }
      loadAllDataFromLocalStorage();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, userRole, router, userId]);

  const loadAllDataFromLocalStorage = () => {
    if (typeof window === 'undefined') return;

    const loadItem = (key: string) => {
        const itemRaw = localStorage.getItem(key);
        if (itemRaw) {
            try {
                const parsedItem = JSON.parse(itemRaw);
                return Array.isArray(parsedItem) ? parsedItem : [];
            } catch (e) {
                console.error(`Failed to parse ${key} from localStorage`, e);
                return [];
            }
        }
        return [];
    };

    setPendingStreams(loadItem(PENDING_STREAMS_KEY));
    setApprovedStreams(loadItem(USER_ADDED_STREAMS_KEY));
    setStreamsPendingDeletion(loadItem(STREAMS_PENDING_DELETION_KEY));
    setDeletedStreamsHistory(loadItem(DELETED_STREAMS_HISTORY_KEY));
    setRegisteredUsers(loadItem(MOCK_USERS_KEY));
  };


  const updateLocalStorage = (key: string, data: Stream[] | User[]) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(key, JSON.stringify(data));
    }
  };

  const handleApproveStream = (streamToApprove: Stream) => {
    const newPendingStreams = pendingStreams.filter(s => s.id !== streamToApprove.id);
    // Ensure creatorId is preserved
    const newApprovedStream = { ...streamToApprove, deletedAt: undefined };
    const newCurrentApprovedStreams = [...approvedStreams.filter(s => s.id !== streamToApprove.id), newApprovedStream];


    setPendingStreams(newPendingStreams);
    setApprovedStreams(newCurrentApprovedStreams);

    updateLocalStorage(PENDING_STREAMS_KEY, newPendingStreams);
    updateLocalStorage(USER_ADDED_STREAMS_KEY, newCurrentApprovedStreams);

    toast({
      title: "Stream Approved",
      description: `${streamToApprove.name} has been approved and is now live.`,
      variant: "default",
    });
    if (selectedStreamForPreview?.id === streamToApprove.id) {
      closePreviewDialog();
    }
  };

  const handleRejectStream = (streamToReject: Stream) => {
    const newPendingStreams = pendingStreams.filter(s => s.id !== streamToReject.id);
    setPendingStreams(newPendingStreams);
    updateLocalStorage(PENDING_STREAMS_KEY, newPendingStreams);

    toast({
      title: "Stream Rejected",
      description: `${streamToReject.name} has been rejected.`,
      variant: "destructive",
    });
     if (selectedStreamForPreview?.id === streamToReject.id) {
      closePreviewDialog();
    }
  };

  const handleDeleteApprovedStream = (streamToDelete: Stream) => {
    const streamWithDeleteTimestamp = { ...streamToDelete, deletedAt: new Date().toISOString() };
    const newDeletedHistory = [...deletedStreamsHistory, streamWithDeleteTimestamp];
    setDeletedStreamsHistory(newDeletedHistory);
    updateLocalStorage(DELETED_STREAMS_HISTORY_KEY, newDeletedHistory as Stream[]);

    const newCurrentApprovedStreams = approvedStreams.filter(s => s.id !== streamToDelete.id);
    setApprovedStreams(newCurrentApprovedStreams);
    updateLocalStorage(USER_ADDED_STREAMS_KEY, newCurrentApprovedStreams);

    toast({
      title: "Stream Removed",
      description: `${streamToDelete.name} has been removed by admin and recorded in history.`,
      variant: "destructive",
    });
  };

  const handleConfirmDeletionRequest = (streamToDelete: Stream) => {
    const streamWithDeleteTimestamp = { ...streamToDelete, deletedAt: new Date().toISOString() };
    const newDeletedHistory = [...deletedStreamsHistory, streamWithDeleteTimestamp];
    setDeletedStreamsHistory(newDeletedHistory);
    updateLocalStorage(DELETED_STREAMS_HISTORY_KEY, newDeletedHistory as Stream[]);

    const newStreamsPendingDeletion = streamsPendingDeletion.filter(s => s.id !== streamToDelete.id);
    setStreamsPendingDeletion(newStreamsPendingDeletion);
    updateLocalStorage(STREAMS_PENDING_DELETION_KEY, newStreamsPendingDeletion);

    // Also ensure it's removed from the main approved list if it was somehow still there
    const newCurrentApprovedStreams = approvedStreams.filter(s => s.id !== streamToDelete.id);
    if (newCurrentApprovedStreams.length !== approvedStreams.length) {
        setApprovedStreams(newCurrentApprovedStreams);
        updateLocalStorage(USER_ADDED_STREAMS_KEY, newCurrentApprovedStreams);
    }

    toast({
      title: "Deletion Confirmed",
      description: `${streamToDelete.name} has been permanently deleted and recorded in history.`,
      variant: "default",
    });
    if (selectedStreamForPreview?.id === streamToDelete.id) {
        closePreviewDialog();
      }
  };

  const handleRejectDeletionRequest = (streamToRestore: Stream) => {
    const newStreamsPendingDeletion = streamsPendingDeletion.filter(s => s.id !== streamToRestore.id);
    setStreamsPendingDeletion(newStreamsPendingDeletion);
    updateLocalStorage(STREAMS_PENDING_DELETION_KEY, newStreamsPendingDeletion);

    // Ensure creatorId is preserved when restoring
    const streamToReapprove = { ...streamToRestore, deletedAt: undefined };
    const currentApproved = [...approvedStreams];
    if (!currentApproved.find(s => s.id === streamToReapprove.id)) {
        currentApproved.push(streamToReapprove);
    }
    setApprovedStreams(currentApproved);
    updateLocalStorage(USER_ADDED_STREAMS_KEY, currentApproved);

    toast({
      title: "Deletion Rejected",
      description: `${streamToRestore.name} has been restored and is active again.`,
      variant: "default",
    });
     if (selectedStreamForPreview?.id === streamToRestore.id) {
        closePreviewDialog();
      }
  };

  const validateUrlForForm = (url: string, fieldName: string, isPrimary = false) => {
    if (isPrimary && !url.trim()) {
        toast({
            title: "Validation Error",
            description: `${fieldName} is required.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && (!url.trim().startsWith('http://') && !url.trim().startsWith('https://'))) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must start with http:// or https://.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && !url.trim().endsWith('.m3u8')) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must end with .m3u8.`,
            variant: "destructive",
        });
        return false;
    }
    return true;
  };

  const handleAddNewStreamSubmit = () => {
    if (!newStreamName.trim()) {
      toast({ title: "Validation Error", description: "Stream Name is required.", variant: "destructive" });
      return;
    }
    if (!validateUrlForForm(newStreamUrl1, "Primary HLS URL", true)) return;
    if (newStreamUrl2.trim() && !validateUrlForForm(newStreamUrl2, "Backup HLS URL 1")) return;
    if (newStreamUrl3.trim() && !validateUrlForForm(newStreamUrl3, "Backup HLS URL 2")) return;

    if (!userId) { // Should always be true for admin, but good check
      toast({ title: "Authentication Error", description: "Admin User ID not found. Cannot submit stream.", variant: "destructive" });
      return;
    }

    const sourceUrls = [newStreamUrl1.trim()];
    if (newStreamUrl2.trim()) sourceUrls.push(newStreamUrl2.trim());
    if (newStreamUrl3.trim()) sourceUrls.push(newStreamUrl3.trim());

    const newStream: Stream = {
      id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: newStreamName.trim(),
      sourceUrls: sourceUrls,
      description: newStreamDescription.trim() || undefined,
      views: 0,
      creatorId: userId, // Admin's ID
    };

    if (typeof window !== 'undefined') {
        const pendingStreamsRaw = localStorage.getItem(PENDING_STREAMS_KEY);
        let currentPendingStreams: Stream[] = [];
        if (pendingStreamsRaw) {
            try {
                const parsed = JSON.parse(pendingStreamsRaw);
                if (Array.isArray(parsed)) currentPendingStreams = parsed;
            } catch (e) { console.error("Error parsing pending streams for new submission by admin:", e); }
        }
        currentPendingStreams.push(newStream);
        localStorage.setItem(PENDING_STREAMS_KEY, JSON.stringify(currentPendingStreams));
        
        toast({ title: "Stream Submitted by Admin", description: `${newStream.name} has been submitted to the pending queue. You can preview it now.` });
        setLastSubmittedStreamForPreview(newStream);
        setIsPreviewSubmittedStreamDialogOpen(true);
    }

    setNewStreamName('');
    setNewStreamUrl1('');
    setNewStreamUrl2('');
    setNewStreamUrl3('');
    setNewStreamDescription('');
  };

  const openPreviewDialog = (stream: Stream) => {
    setSelectedStreamForPreview(stream);
    setActivePreviewPlayingUrl(null);
    setIsPreviewDialogOpen(true);
  };

  const closePreviewDialog = () => {
    setIsPreviewDialogOpen(false);
    setSelectedStreamForPreview(null);
    setActivePreviewPlayingUrl(null);
  };


  if (!isClient || !isAuthenticated || userRole !== 'admin') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
        <Card className="w-full max-w-2xl shadow-xl rounded-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center">
              You must be logged in as an admin to view this page. Redirecting to login...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center bg-background p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-4xl space-y-8">
        <Card className="shadow-xl rounded-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-8 h-8 text-primary" />
              <CardTitle className="text-3xl font-bold text-foreground">Admin Dashboard</CardTitle>
            </div>
            <div className="flex items-center gap-2">
                <Button variant="outline" asChild>
                  <Link href="/" className="flex items-center gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Home
                  </Link>
                </Button>
                <Button variant="ghost" onClick={logout} className="text-destructive-foreground hover:bg-destructive/10">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Approved Streams Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground">Approved Streams</CardTitle>
            <CardDescription>
              Manage currently active streams. Direct deletion by admin is permanent and recorded in history.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {approvedStreams.length === 0 ? (
              <p className="text-muted-foreground">No user-added streams have been approved yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Creator ID</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {approvedStreams.map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">{stream.description || "N/A"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground truncate">{stream.creatorId || "System/Initial"}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openPreviewDialog(stream)}
                          aria-label={`Preview ${stream.name}`}
                        >
                          <Eye className="w-4 h-4 mr-1" /> Preview
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          onClick={() => handleDeleteApprovedStream(stream)}
                          aria-label={`Admin delete approved stream ${stream.name}`}
                        >
                          <Trash2 className="w-4 h-4 mr-1" /> Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Add New Stream Section by Admin */}
        <Card className="shadow-md border border-border">
            <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2 text-foreground">
                <PlusCircle className="w-6 h-6 text-accent" />
                Add New HLS Stream (Submit to Pending Queue)
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                As an admin, you can submit streams here. They will go into the 'Pending Approval' queue for review (even by yourself).
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                <Label htmlFor="new-stream-name-admin" className="text-sm font-medium text-foreground">Stream Name</Label>
                <Input
                    id="new-stream-name-admin"
                    value={newStreamName}
                    onChange={(e) => setNewStreamName(e.target.value)}
                    placeholder="E.g., Admin's Special Broadcast"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url1-admin" className="text-sm font-medium text-foreground">Primary HLS URL (.m3u8)</Label>
                <Input
                    id="new-stream-url1-admin"
                    type="url"
                    value={newStreamUrl1}
                    onChange={(e) => setNewStreamUrl1(e.target.value)}
                    placeholder="https://example.com/live/stream1.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url2-admin" className="text-sm font-medium text-foreground">Backup HLS URL 1 (Optional)</Label>
                <Input
                    id="new-stream-url2-admin"
                    type="url"
                    value={newStreamUrl2}
                    onChange={(e) => setNewStreamUrl2(e.target.value)}
                    placeholder="https://backup.example.com/live/stream2.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url3-admin" className="text-sm font-medium text-foreground">Backup HLS URL 2 (Optional)</Label>
                <Input
                    id="new-stream-url3-admin"
                    type="url"
                    value={newStreamUrl3}
                    onChange={(e) => setNewStreamUrl3(e.target.value)}
                    placeholder="https://another-backup.example.com/live/stream3.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-description-admin" className="text-sm font-medium text-foreground">Description (Optional)</Label>
                <Textarea
                    id="new-stream-description-admin"
                    value={newStreamDescription}
                    onChange={(e) => setNewStreamDescription(e.target.value)}
                    placeholder="A brief description of the stream content."
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                    rows={2}
                />
                </div>
                <Button onClick={handleAddNewStreamSubmit} className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90">
                <PlusCircle className="mr-2 h-4 w-4" /> Submit Stream to Pending Queue
                </Button>
            </CardContent>
        </Card>

        {/* Pending Approval Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground">Pending Approval (New Streams)</CardTitle>
            <CardDescription>
              Review and approve or reject new stream submissions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {pendingStreams.length === 0 ? (
              <p className="text-muted-foreground">No new streams currently pending approval.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Creator ID</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingStreams.map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">{stream.description || "N/A"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground truncate">{stream.creatorId || "N/A"}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openPreviewDialog(stream)}
                          aria-label={`Preview ${stream.name}`}
                        >
                          <Eye className="w-4 h-4 mr-1" /> Preview
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-500 hover:text-green-600 hover:bg-green-500/10"
                          onClick={() => handleApproveStream(stream)}
                          aria-label={`Approve ${stream.name}`}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" /> Approve
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          onClick={() => handleRejectStream(stream)}
                          aria-label={`Reject ${stream.name}`}
                        >
                          <XCircle className="w-4 h-4 mr-1" /> Reject
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* User Deletion Requests Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
              User Deletion Requests
            </CardTitle>
            <CardDescription>
              Review user requests to delete their streams. Approved deletions are recorded in history.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {streamsPendingDeletion.length === 0 ? (
              <p className="text-muted-foreground">No streams currently pending user-requested deletion.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Creator ID</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {streamsPendingDeletion.map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">{stream.description || "N/A"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground truncate">{stream.creatorId || "N/A"}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openPreviewDialog(stream)}
                          aria-label={`Preview ${stream.name}`}
                        >
                          <Eye className="w-4 h-4 mr-1" /> Preview
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          onClick={() => handleConfirmDeletionRequest(stream)}
                          aria-label={`Confirm deletion for ${stream.name}`}
                        >
                          <Trash2 className="w-4 h-4 mr-1" /> Confirm Delete
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-500 hover:text-green-600 hover:bg-green-500/10"
                          onClick={() => handleRejectDeletionRequest(stream)}
                          aria-label={`Reject deletion for ${stream.name}`}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" /> Reject & Restore
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Registered Users Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground flex items-center gap-2">
              <Users className="w-6 h-6 text-primary" />
              Registered Users
            </CardTitle>
            <CardDescription>
              List of users who have authenticated with the system. (User ID is an internal identifier).
            </CardDescription>
          </CardHeader>
          <CardContent>
            {registeredUsers.length === 0 ? (
              <p className="text-muted-foreground">No users have logged in yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Login Method</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead>User ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {registeredUsers.sort((a, b) => new Date(b.lastLogin).getTime() - new Date(a.lastLogin).getTime()).map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell className="capitalize">{user.role}</TableCell>
                      <TableCell className="capitalize">{user.method}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(user.lastLogin).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground truncate">{user.id}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Deleted Streams History Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground flex items-center gap-2">
                <History className="w-6 h-6 text-primary" />
                Deleted Streams History
            </CardTitle>
            <CardDescription>
              A record of all streams permanently deleted by an admin.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {deletedStreamsHistory.length === 0 ? (
              <p className="text-muted-foreground">No streams have been deleted yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Creator ID</TableHead>
                    <TableHead>Deleted At</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {deletedStreamsHistory.sort((a, b) => new Date(b.deletedAt!).getTime() - new Date(a.deletedAt!).getTime()).map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">{stream.description || "N/A"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground truncate">{stream.creatorId || "N/A"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {stream.deletedAt ? new Date(stream.deletedAt).toLocaleString() : "N/A"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

      </div>

      {/* Preview Stream Dialog (used for pending, approved, deletion requests) */}
      {selectedStreamForPreview && (
        <Dialog open={isPreviewDialogOpen} onOpenChange={(isOpen) => {
          if (!isOpen) {
            closePreviewDialog();
          }
        }}>
          <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px] w-full">
            <DialogHeader>
              <DialogTitle>Preview: {selectedStreamForPreview.name}</DialogTitle>
              {selectedStreamForPreview.description && (
                <DialogDescription>{selectedStreamForPreview.description}</DialogDescription>
              )}
            </DialogHeader>
            <div className="my-4 rounded-lg overflow-hidden">
              <HlsPlayer
                src={selectedStreamForPreview.sourceUrls}
                autoPlay={true}
                onActiveSourceChanged={setActivePreviewPlayingUrl}
              />
            </div>
            {activePreviewPlayingUrl && (
              <div className="mt-2 text-sm">
                <span className="font-medium text-foreground">Active Source: </span>
                <code className="text-xs bg-muted p-1 rounded-sm break-all text-muted-foreground">{activePreviewPlayingUrl}</code>
              </div>
            )}
            <DialogFooter className="mt-4">
              <Button type="button" variant="secondary" onClick={closePreviewDialog}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Preview Newly Submitted Stream by Admin Dialog */}
      {lastSubmittedStreamForPreview && (
        <Dialog open={isPreviewSubmittedStreamDialogOpen} onOpenChange={setIsPreviewSubmittedStreamDialogOpen}>
          <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px] w-full">
            <DialogHeader>
              <DialogTitle>Previewing Your Submission: {lastSubmittedStreamForPreview.name}</DialogTitle>
              {lastSubmittedStreamForPreview.description && (
                <DialogDescription>{lastSubmittedStreamForPreview.description}</DialogDescription>
              )}
               <DialogDescription className="text-xs text-muted-foreground pt-1">
                This stream has been submitted to the pending queue.
              </DialogDescription>
            </DialogHeader>
            <div className="my-4 rounded-lg overflow-hidden">
              <HlsPlayer src={lastSubmittedStreamForPreview.sourceUrls} autoPlay={true} />
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsPreviewSubmittedStreamDialogOpen(false)}>
                Close Preview
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </main>
  );
}

    
