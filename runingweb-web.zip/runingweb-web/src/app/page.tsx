
"use client";

import { HlsPlayer } from "@/components/stream-player";
import { StreamThumbnailCard } from "@/components/stream-thumbnail-card";
import { useState, useEffect } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { Stream, User } from "@/types";
import { Eye, PlusCircle, ShieldCheck, UserCog, LogIn, LogOut, UserPlus, Heart, MessageSquare, Clock, DollarSign, Bitcoin as BitcoinIcon } from "lucide-react";
import { RuningaLogo } from "@/components/icons/runinga-logo";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { initialStreamsData } from "@/lib/initial-streams";
import { useAuth } from "@/contexts/AuthContext";


const PENDING_STREAMS_KEY = 'pendingAdminStreams';
const USER_ADDED_STREAMS_KEY = 'userAddedStreams';
const STREAM_LIKES_KEY = 'streamLikes';
const STREAM_COMMENTS_KEY = 'streamComments';
const MOCK_USERS_KEY = 'mockRegisteredUsers';

type Comment = {
  id: string;
  userId: string;
  username: string;
  text: string;
  timestamp: string;
};

export default function Home() {
  const [isClient, setIsClient] = useState(false);
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
  const [streams, setStreams] = useState<Stream[]>([]);
  const { toast } = useToast();
  const { isAuthenticated, logout, userRole, userId } = useAuth();

  const [newStreamName, setNewStreamName] = useState('');
  const [newStreamUrl1, setNewStreamUrl1] = useState('');
  const [newStreamUrl2, setNewStreamUrl2] = useState('');
  const [newStreamUrl3, setNewStreamUrl3] = useState('');
  const [newStreamDescription, setNewStreamDescription] = useState('');

  const [lastSubmittedStreamForPreview, setLastSubmittedStreamForPreview] = useState<Stream | null>(null);
  const [isPreviewSubmittedStreamDialogOpen, setIsPreviewSubmittedStreamDialogOpen] = useState(false);

  // State for likes and comments
  const [currentStreamLikes, setCurrentStreamLikes] = useState<string[]>([]); // Array of userIds
  const [currentStreamComments, setCurrentStreamComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');

  // State for dynamic info display
  const [currentTime, setCurrentTime] = useState('');
  const [usdToKes, setUsdToKes] = useState('USD/KES: Loading...');
  const [btcToUsdt, setBtcToUsdt] = useState('BTC/USDT: Loading...');

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      let streamsToDisplay: Stream[] = [];
      const storedUserAddedStreamsRaw = localStorage.getItem(USER_ADDED_STREAMS_KEY);

      if (storedUserAddedStreamsRaw) {
        try {
          const parsedUserAddedStreams: Stream[] = JSON.parse(storedUserAddedStreamsRaw);
          if (Array.isArray(parsedUserAddedStreams)) {
            const userAddedStreamIds = new Set(parsedUserAddedStreams.map(s => s.id));
            const allStreamsWithViews = parsedUserAddedStreams.map(s => ({
              ...s,
              views: s.views || 0 
            }));

            const uniqueInitialStreams = initialStreamsData
              .filter(s => !userAddedStreamIds.has(s.id))
              .map(s => ({ ...s, views: s.views || 0 })); 

            streamsToDisplay = [...allStreamsWithViews.filter(s => !s.deletedAt), ...uniqueInitialStreams].reverse();
          } else {
            console.warn(`${USER_ADDED_STREAMS_KEY} in localStorage was not an array. Initializing with default streams.`);
            streamsToDisplay = initialStreamsData.map(s => ({ ...s, views: s.views || 0 })).reverse();
            localStorage.setItem(USER_ADDED_STREAMS_KEY, JSON.stringify(initialStreamsData.map(s => ({ ...s, views: s.views || 0}))));
          }
        } catch (e) {
          console.error(`Failed to parse ${USER_ADDED_STREAMS_KEY} from localStorage. Initializing with default streams.`, e);
          streamsToDisplay = initialStreamsData.map(s => ({ ...s, views: s.views || 0 })).reverse();
          localStorage.setItem(USER_ADDED_STREAMS_KEY, JSON.stringify(initialStreamsData.map(s => ({ ...s, views: s.views || 0}))));
        }
      } else {
        console.log(`${USER_ADDED_STREAMS_KEY} not found in localStorage. Initializing with default streams.`);
        streamsToDisplay = initialStreamsData.map(s => ({ ...s, views: s.views || 0 })).reverse();
        localStorage.setItem(USER_ADDED_STREAMS_KEY, JSON.stringify(initialStreamsData.map(s => ({ ...s, views: s.views || 0}))));
      }
      
      setStreams(streamsToDisplay);

      // Set time interval
      const updateTime = () => {
        setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      };
      updateTime(); // Initial call
      const timerId = setInterval(updateTime, 1000);

      // Fetch exchange rate
      const fetchExchangeRate = async () => {
        try {
          // IMPORTANT: For production, move API calls to server-side (e.g., Next.js API route) to protect API keys and manage rate limits.
          const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
          if (!response.ok) throw new Error('Failed to fetch exchange rate');
          const data = await response.json();
          if (data.rates && data.rates.KES) {
            setUsdToKes(`1 USD = ${data.rates.KES.toFixed(2)} KES`);
          } else {
            setUsdToKes('USD/KES: N/A');
          }
        } catch (error) {
          console.error("Error fetching exchange rate:", error);
          setUsdToKes('USD/KES: Error');
        }
      };

      // Fetch crypto price
      const fetchCryptoPrice = async () => {
        try {
          // IMPORTANT: For production, move API calls to server-side.
          const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usdt');
          if (!response.ok) throw new Error('Failed to fetch crypto price');
          const data = await response.json();
          if (data.bitcoin && data.bitcoin.usdt) {
            setBtcToUsdt(`1 BTC = ${data.bitcoin.usdt.toLocaleString()} USDT`);
          } else {
            setBtcToUsdt('BTC/USDT: N/A');
          }
        } catch (error) {
          console.error("Error fetching crypto price:", error);
          setBtcToUsdt('BTC/USDT: Error');
        }
      };

      fetchExchangeRate();
      fetchCryptoPrice();

      return () => {
        clearInterval(timerId); // Cleanup interval on component unmount
      };
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Effect to load likes and comments when a stream is selected
  useEffect(() => {
    if (selectedStream && typeof window !== 'undefined') {
      const allLikesRaw = localStorage.getItem(STREAM_LIKES_KEY);
      let allLikes: Record<string, string[]> = {};
      if (allLikesRaw) {
        try { allLikes = JSON.parse(allLikesRaw); } catch (e) { console.error("Error parsing likes", e); }
      }
      setCurrentStreamLikes(allLikes[selectedStream.id] || []);

      const allCommentsRaw = localStorage.getItem(STREAM_COMMENTS_KEY);
      let allComments: Record<string, Comment[]> = {};
      if (allCommentsRaw) {
        try { allComments = JSON.parse(allCommentsRaw); } catch (e) { console.error("Error parsing comments", e); }
      }
      setCurrentStreamComments((allComments[selectedStream.id] || []).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    } else {
      setCurrentStreamLikes([]);
      setCurrentStreamComments([]);
    }
  }, [selectedStream]);


  const validateUrl = (url: string, fieldName: string, isPrimary = false) => {
    if (isPrimary && !url.trim()) {
        toast({
            title: "Validation Error",
            description: `${fieldName} is required.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && (!url.trim().startsWith('http://') && !url.trim().startsWith('https://'))) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must start with http:// or https://.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && !url.trim().endsWith('.m3u8')) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must end with .m3u8 (e.g., https://example.com/stream.m3u8).`,
            variant: "destructive",
        });
        return false;
    }
    return true;
  }

  const handleAddStream = () => {
    if (!newStreamName.trim()) {
      toast({ title: "Validation Error", description: "Stream Name is required.", variant: "destructive" });
      return;
    }
    if (!validateUrl(newStreamUrl1, "Primary HLS URL", true)) return;
    if (newStreamUrl2.trim() && !validateUrl(newStreamUrl2, "Backup HLS URL 1")) return;
    if (newStreamUrl3.trim() && !validateUrl(newStreamUrl3, "Backup HLS URL 2")) return;

    if (!userId) {
      toast({ title: "Authentication Error", description: "You must be logged in to submit a stream.", variant: "destructive" });
      return;
    }

    const sourceUrls = [newStreamUrl1.trim()];
    if (newStreamUrl2.trim()) sourceUrls.push(newStreamUrl2.trim());
    if (newStreamUrl3.trim()) sourceUrls.push(newStreamUrl3.trim());

    const newStream: Stream = {
      id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: newStreamName.trim(),
      sourceUrls: sourceUrls,
      description: newStreamDescription.trim() || undefined,
      views: 0, 
      creatorId: userId,
    };

    if (typeof window !== 'undefined') {
        const pendingStreamsRaw = localStorage.getItem(PENDING_STREAMS_KEY);
        let pendingStreams: Stream[] = [];
        if (pendingStreamsRaw) {
            try {
                const parsed = JSON.parse(pendingStreamsRaw);
                if (Array.isArray(parsed)) pendingStreams = parsed;
            } catch (e) { console.error("Error parsing pending streams:", e); }
        }
        pendingStreams.push(newStream);
        localStorage.setItem(PENDING_STREAMS_KEY, JSON.stringify(pendingStreams));
        console.log('Updated pending streams in localStorage:', JSON.stringify(pendingStreams));

        toast({ title: "Stream Submitted", description: `${newStream.name} has been submitted for approval. You can preview it now.` });
        setLastSubmittedStreamForPreview(newStream);
        setIsPreviewSubmittedStreamDialogOpen(true);
    }

    setNewStreamName('');
    setNewStreamUrl1('');
    setNewStreamUrl2('');
    setNewStreamUrl3('');
    setNewStreamDescription('');
  };

  const handleLikeStream = () => {
    if (!selectedStream || !userId || !isAuthenticated) {
      toast({ title: "Login Required", description: "You must be logged in to like a stream.", variant: "destructive"});
      return;
    }

    const allLikesRaw = localStorage.getItem(STREAM_LIKES_KEY);
    let allLikes: Record<string, string[]> = {};
    if (allLikesRaw) {
      try { allLikes = JSON.parse(allLikesRaw); } catch (e) { console.error("Error parsing likes", e); }
    }

    let streamLikes = allLikes[selectedStream.id] || [];
    const userIndex = streamLikes.indexOf(userId);

    if (userIndex > -1) { 
      streamLikes.splice(userIndex, 1);
    } else { 
      streamLikes.push(userId);
    }

    allLikes[selectedStream.id] = streamLikes;
    localStorage.setItem(STREAM_LIKES_KEY, JSON.stringify(allLikes));
    setCurrentStreamLikes([...streamLikes]);
  };

  const handleAddComment = () => {
    if (!selectedStream || !userId || !isAuthenticated || !newCommentText.trim()) {
      if (!isAuthenticated || !userId) {
        toast({ title: "Login Required", description: "You must be logged in to comment.", variant: "destructive"});
      } else if (!newCommentText.trim()) {
         toast({ title: "Empty Comment", description: "Comment cannot be empty.", variant: "destructive"});
      }
      return;
    }

    const usersRaw = localStorage.getItem(MOCK_USERS_KEY);
    let users: User[] = [];
    if (usersRaw) {
        try { 
          const parsedUsers = JSON.parse(usersRaw);
          if(Array.isArray(parsedUsers)) users = parsedUsers;
        } catch(e) { console.error("Error fetching users for comment username", e); }
    }
    const currentUserDetails = users.find(u => u.id === userId);
    const username = currentUserDetails ? currentUserDetails.username : "Anonymous";


    const allCommentsRaw = localStorage.getItem(STREAM_COMMENTS_KEY);
    let allComments: Record<string, Comment[]> = {};
    if (allCommentsRaw) {
      try { allComments = JSON.parse(allCommentsRaw); } catch (e) { console.error("Error parsing comments", e); }
    }

    let streamComments = allComments[selectedStream.id] || [];
    const newComment: Comment = {
      id: `comment-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      userId,
      username,
      text: newCommentText.trim(),
      timestamp: new Date().toISOString(),
    };

    streamComments.push(newComment);
    allComments[selectedStream.id] = streamComments.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    localStorage.setItem(STREAM_COMMENTS_KEY, JSON.stringify(allComments));
    setCurrentStreamComments([...allComments[selectedStream.id]]); 
    setNewCommentText('');
  };


  if (!isClient) {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
             <Card className="w-full max-w-4xl shadow-2xl rounded-xl">
                <CardHeader className="bg-card-foreground/5">
                    <div className="flex items-center justify-center gap-3">
                        <RuningaLogo className="h-[3.6rem] w-auto text-primary-foreground" />
                        <CardTitle className="text-center text-3xl font-bold text-primary-foreground">RUNINGA - TELEVISION</CardTitle>
                    </div>
                    {/* Placeholder for dynamic info while loading */}
                    <div className="mt-2 flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>Loading time...</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            <span>USD/KES: Loading...</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <BitcoinIcon className="w-3 h-3" />
                            <span>BTC/USDT: Loading...</span>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="flex flex-col gap-6 items-center p-6">
                    <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center">
                        <p className="text-muted-foreground">Loading streams...</p>
                    </div>
                     <p className="text-muted-foreground text-center">Please wait while streams are being prepared.</p>
                </CardContent>
            </Card>
        </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center bg-background p-4 relative">
        <Card className="w-full max-w-4xl shadow-2xl rounded-xl overflow-hidden my-8">
            <CardHeader className="bg-card-foreground/5">
                <div className="flex items-center justify-center gap-3">
                    <Button
                        variant="ghost"
                        onClick={() => setSelectedStream(null)}
                        aria-label="Go to homepage"
                        className="p-0 h-auto focus-visible:ring-ring focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded"
                    >
                        <RuningaLogo className="h-[3.6rem] w-auto text-primary-foreground" />
                    </Button>
                    <CardTitle className="text-3xl font-bold text-primary-foreground">
                        {selectedStream ? selectedStream.name : "RUNINGA - TELEVISION"}
                    </CardTitle>
                 </div>
                 {/* Dynamic Info Display */}
                <div className="mt-2 flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-4 text-xs text-muted-foreground">
                    {currentTime && (
                        <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{currentTime}</span>
                        </div>
                    )}
                    <div className="flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />
                        <span>{usdToKes}</span>
                    </div>
                    <div className="flex items-center gap-1">
                        <BitcoinIcon className="w-3 h-3" />
                        <span>{btcToUsdt}</span>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-6">
                {selectedStream ? (
                    <div className="flex flex-col gap-6 items-center">
                        <HlsPlayer src={selectedStream.sourceUrls} autoPlay={true} />
                        {selectedStream.description && (
                            <p className="text-muted-foreground text-center mt-2">{selectedStream.description}</p>
                        )}
                        <div className="flex items-center justify-between w-full max-w-xl mt-2">
                            <div className="flex items-center gap-1 text-muted-foreground text-sm">
                                <Eye className="w-4 h-4" />
                                <span>{selectedStream.views.toLocaleString()} views</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={handleLikeStream}
                                    disabled={!isAuthenticated || !userId} 
                                    className={`text-muted-foreground hover:text-accent ${!isAuthenticated || !userId ? 'cursor-not-allowed opacity-50' : ''}`}
                                    aria-pressed={userId ? currentStreamLikes.includes(userId) : false}
                                >
                                    <Heart className={`w-5 h-5 mr-1 ${userId && currentStreamLikes.includes(userId) ? 'fill-red-500 text-red-500' : 'text-muted-foreground'}`} />
                                    {currentStreamLikes.length}
                                </Button>
                                <div className="flex items-center gap-1 text-muted-foreground text-sm">
                                  <MessageSquare className="w-4 h-4" />
                                  <span>{currentStreamComments.length}</span>
                                </div>
                            </div>
                        </div>

                        <div className="w-full max-w-xl mt-4 space-y-4">
                          <h3 className="text-lg font-semibold text-foreground">Comments</h3>
                          {isAuthenticated && userId ? ( 
                            <div className="flex flex-col gap-2">
                              <Textarea
                                value={newCommentText}
                                onChange={(e) => setNewCommentText(e.target.value)}
                                placeholder="Add a comment..."
                                className="bg-input border-border placeholder:text-muted-foreground"
                                rows={2}
                              />
                              <Button onClick={handleAddComment} size="sm" className="self-end bg-accent text-accent-foreground hover:bg-accent/90">
                                Post Comment
                              </Button>
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">
                                <Link href="/login" className="underline hover:text-accent">Login or create an account</Link> to post a comment.
                            </p>
                          )}
                          {currentStreamComments.length > 0 ? (
                            <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                              {currentStreamComments.map(comment => (
                                <div key={comment.id} className="p-3 rounded-md bg-muted/50 border border-border/50">
                                  <div className="flex items-center justify-between text-xs mb-1">
                                    <span className="font-semibold text-foreground">{comment.username}</span>
                                    <span className="text-muted-foreground">{new Date(comment.timestamp).toLocaleString()}</span>
                                  </div>
                                  <p className="text-sm text-foreground">{comment.text}</p>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">No comments yet. {isAuthenticated && userId ? 'Be the first to comment!' : ''}</p>
                          )}
                        </div>
                        
                        <Button
                            onClick={() => setSelectedStream(null)}
                            variant="outline"
                            className="mt-4 self-center"
                            aria-label="Back to streams list"
                        >
                            Back to Streams
                        </Button>
                    </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
                        {streams.map((stream) => (
                            <StreamThumbnailCard
                                key={stream.id}
                                stream={stream}
                                onStreamSelect={setSelectedStream}
                            />
                        ))}
                    </div>

                    {streams.length === 0 && (
                      <p className="text-center text-muted-foreground mb-8">
                        No streams available. Add a new HLS stream using the form below for admin approval.
                      </p>
                    )}

                    {isAuthenticated && (userRole === 'creator' || userRole === 'admin') && (
                        <Card className="shadow-md border border-border">
                        <CardHeader>
                            <CardTitle className="text-xl flex items-center gap-2 text-foreground">
                            <PlusCircle className="w-6 h-6 text-accent" />
                            Add New HLS Stream (for Admin Approval)
                            </CardTitle>
                            <CardDescription className="text-muted-foreground">
                            Provide up to three HLS URLs (.m3u8) for a stream. The player will attempt to play them in order. Submitted streams require admin approval.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                            <Label htmlFor="new-stream-name" className="text-sm font-medium text-foreground">Stream Name</Label>
                            <Input
                                id="new-stream-name"
                                value={newStreamName}
                                onChange={(e) => setNewStreamName(e.target.value)}
                                placeholder="E.g., My Awesome Live Event"
                                className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                            />
                            </div>
                            <div>
                            <Label htmlFor="new-stream-url1" className="text-sm font-medium text-foreground">Primary HLS URL (.m3u8)</Label>
                            <Input
                                id="new-stream-url1"
                                type="url"
                                value={newStreamUrl1}
                                onChange={(e) => setNewStreamUrl1(e.target.value)}
                                placeholder="https://example.com/live/stream1.m3u8"
                                className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                            />
                            </div>
                            <div>
                            <Label htmlFor="new-stream-url2" className="text-sm font-medium text-foreground">Backup HLS URL 1 (Optional)</Label>
                            <Input
                                id="new-stream-url2"
                                type="url"
                                value={newStreamUrl2}
                                onChange={(e) => setNewStreamUrl2(e.target.value)}
                                placeholder="https://backup.example.com/live/stream2.m3u8"
                                className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                            />
                            </div>
                            <div>
                            <Label htmlFor="new-stream-url3" className="text-sm font-medium text-foreground">Backup HLS URL 2 (Optional)</Label>
                            <Input
                                id="new-stream-url3"
                                type="url"
                                value={newStreamUrl3}
                                onChange={(e) => setNewStreamUrl3(e.target.value)}
                                placeholder="https://another-backup.example.com/live/stream3.m3u8"
                                className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                            />
                            </div>
                            <div>
                            <Label htmlFor="new-stream-description" className="text-sm font-medium text-foreground">Description (Optional)</Label>
                            <Textarea
                                id="new-stream-description"
                                value={newStreamDescription}
                                onChange={(e) => setNewStreamDescription(e.target.value)}
                                placeholder="A brief description of the stream content."
                                className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                                rows={2}
                            />
                            </div>
                            <Button onClick={handleAddStream} className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90">
                            <PlusCircle className="mr-2 h-4 w-4" /> Submit Stream for Approval
                            </Button>
                        </CardContent>
                        </Card>
                    )}
                  </>
                )}
            </CardContent>
        </Card>
         {isClient && (
            <div className="fixed bottom-6 right-6 flex flex-col items-end gap-2">
                {isAuthenticated ? (
                    <>
                        {userRole === 'creator' && (
                            <Link
                                href="/user-dashboard"
                                className="bg-primary text-primary-foreground p-3 rounded-lg shadow-xl hover:bg-primary/90 transition-colors flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                                aria-label="Creator Dashboard"
                            >
                                <UserCog className="w-5 h-5" />
                                Creator Dashboard
                            </Link>
                        )}
                        {userRole === 'admin' && (
                            <Link
                                href="/admin"
                                className="bg-primary text-primary-foreground p-3 rounded-lg shadow-xl hover:bg-primary/90 transition-colors flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                                aria-label="Admin Dashboard"
                            >
                                <ShieldCheck className="w-5 h-5" />
                                Admin Dashboard
                            </Link>
                        )}
                         <Button
                            onClick={logout}
                            variant="destructive"
                            className="p-3 rounded-lg shadow-xl transition-colors flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                            aria-label="Logout"
                        >
                            <LogOut className="w-5 h-5" />
                            Logout
                        </Button>
                    </>
                ) : (
                    <div className="flex flex-col items-end gap-2">
                        <Link
                            href="/login"
                            className="bg-accent text-accent-foreground p-3 rounded-lg shadow-xl hover:bg-accent/90 transition-colors flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                            aria-label="Login"
                        >
                            <LogIn className="w-5 h-5" />
                            Login
                        </Link>
                        <Link
                            href="/login" 
                            className="bg-green-600 text-white p-3 rounded-lg shadow-xl hover:bg-green-700 transition-colors flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                            aria-label="Create Account"
                        >
                            <UserPlus className="w-5 h-5" />
                            Create Account
                        </Link>
                    </div>
                )}
            </div>
        )}

      {lastSubmittedStreamForPreview && (
        <Dialog open={isPreviewSubmittedStreamDialogOpen} onOpenChange={setIsPreviewSubmittedStreamDialogOpen}>
          <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px] w-full">
            <DialogHeader>
              <DialogTitle>Previewing Your Submission: {lastSubmittedStreamForPreview.name}</DialogTitle>
              {lastSubmittedStreamForPreview.description && (
                <DialogDescription>{lastSubmittedStreamForPreview.description}</DialogDescription>
              )}
               <DialogDescription className="text-xs text-muted-foreground pt-1">
                This stream has been submitted for admin approval.
              </DialogDescription>
            </DialogHeader>
            <div className="my-4 rounded-lg overflow-hidden">
              <HlsPlayer src={lastSubmittedStreamForPreview.sourceUrls} autoPlay={true} />
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsPreviewSubmittedStreamDialogOpen(false)}>
                Close Preview
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </main>
  );
}
    

    


