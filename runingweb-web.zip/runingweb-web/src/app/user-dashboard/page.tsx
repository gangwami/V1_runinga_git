
"use client";

import { useState, useEffect } from "react";
import type { Stream } from "@/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Edit, UserCog, Send, Eye, Users, LogOut, PlusCircle } from "lucide-react"; // Added PlusCircle
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { HlsPlayer } from "@/components/stream-player";
// Removed initialStreamsData import as it's handled differently for creator dashboard
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";

const USER_ADDED_STREAMS_KEY = 'userAddedStreams';
const STREAMS_PENDING_DELETION_KEY = 'streamsPendingDeletion';
const PENDING_STREAMS_KEY = 'pendingAdminStreams'; // For submitting new streams

export default function UserDashboardPage() {
  const [isClient, setIsClient] = useState(false);
  const [editableStreams, setEditableStreams] = useState<Stream[]>([]);
  const [editingStream, setEditingStream] = useState<Stream | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  // State for editing an existing stream
  const [editedName, setEditedName] = useState('');
  const [editedUrl1, setEditedUrl1] = useState('');
  const [editedUrl2, setEditedUrl2] = useState('');
  const [editedUrl3, setEditedUrl3] = useState('');
  const [editedDescription, setEditedDescription] = useState('');

  // State for previewing an existing stream from the table
  const [selectedStreamForPreview, setSelectedStreamForPreview] = useState<Stream | null>(null);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [activePreviewPlayingUrl, setActivePreviewPlayingUrl] = useState<string | null>(null);

  // State for adding a new stream
  const [newStreamName, setNewStreamName] = useState('');
  const [newStreamUrl1, setNewStreamUrl1] = useState('');
  const [newStreamUrl2, setNewStreamUrl2] = useState('');
  const [newStreamUrl3, setNewStreamUrl3] = useState('');
  const [newStreamDescription, setNewStreamDescription] = useState('');
  const [lastSubmittedStreamForPreview, setLastSubmittedStreamForPreview] = useState<Stream | null>(null);
  const [isPreviewSubmittedStreamDialogOpen, setIsPreviewSubmittedStreamDialogOpen] = useState(false);


  const { isAuthenticated, userRole, logout, userId } = useAuth();
  const router = useRouter();

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      if (!isAuthenticated || userRole !== 'creator' || !userId) {
        router.push('/login');
        return;
      }
      loadStreamsFromLocalStorage();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, userRole, router, userId]);


  const loadStreamsFromLocalStorage = () => {
    if (!userId) return;

    let streamsToDisplayForCreator: Stream[] = [];
    const streamsRaw = localStorage.getItem(USER_ADDED_STREAMS_KEY);

    if (streamsRaw) {
        try {
            const parsed = JSON.parse(streamsRaw) as Stream[];
            if (Array.isArray(parsed)) {
                streamsToDisplayForCreator = parsed.filter(s => s.creatorId === userId && !s.deletedAt).reverse();
            } else {
                console.warn(`${USER_ADDED_STREAMS_KEY} in localStorage was not an array. User will see no streams initially.`);
            }
        } catch (e) {
            console.error(`Failed to parse ${USER_ADDED_STREAMS_KEY} from localStorage. User will see no streams.`, e);
        }
    } else {
        console.log(`${USER_ADDED_STREAMS_KEY} not found in localStorage. User will see no streams initially.`);
    }
    setEditableStreams(streamsToDisplayForCreator);
  };


  const updateLocalStorage = (key: string, data: Stream[]) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(key, JSON.stringify(data));
    }
  };

  const handleEditStream = (streamToEdit: Stream) => {
    setEditingStream(streamToEdit);
    setEditedName(streamToEdit.name);
    setEditedUrl1(streamToEdit.sourceUrls[0] || '');
    setEditedUrl2(streamToEdit.sourceUrls[1] || '');
    setEditedUrl3(streamToEdit.sourceUrls[2] || '');
    setEditedDescription(streamToEdit.description || '');
    setIsEditDialogOpen(true);
  };

  // Re-declaring validateUrl here. Consider moving to a shared utils file if used in more places.
  const validateUrlForForm = (url: string, fieldName: string, isPrimary = false) => {
    if (isPrimary && !url.trim()) {
        toast({
            title: "Validation Error",
            description: `${fieldName} is required.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && (!url.trim().startsWith('http://') && !url.trim().startsWith('https://'))) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must start with http:// or https://.`,
            variant: "destructive",
        });
        return false;
    }
    if (url.trim() && !url.trim().endsWith('.m3u8')) {
        toast({
            title: "Validation Error",
            description: `URL for "${fieldName}" must end with .m3u8.`,
            variant: "destructive",
        });
        return false;
    }
    return true;
  };

  const handleSaveStream = () => {
    if (!editingStream || !userId) return;

    if (!editedName.trim()) {
      toast({ title: "Validation Error", description: "Stream Name is required.", variant: "destructive" });
      return;
    }
    if (!validateUrlForForm(editedUrl1, "Primary HLS URL", true)) return;
    if (editedUrl2.trim() && !validateUrlForForm(editedUrl2, "Backup HLS URL 1")) return;
    if (editedUrl3.trim() && !validateUrlForForm(editedUrl3, "Backup HLS URL 2")) return;

    const updatedSourceUrls = [editedUrl1.trim()];
    if (editedUrl2.trim()) updatedSourceUrls.push(editedUrl2.trim());
    if (editedUrl3.trim()) updatedSourceUrls.push(editedUrl3.trim());

    const currentStoredUserStreamsRaw = localStorage.getItem(USER_ADDED_STREAMS_KEY);
    let currentStoredUserStreams: Stream[] = [];
    if (currentStoredUserStreamsRaw) {
        try {
            const parsed = JSON.parse(currentStoredUserStreamsRaw);
             if (Array.isArray(parsed)) {
                currentStoredUserStreams = parsed;
            } else {
                console.warn("User added streams from localStorage was not an array, may lose existing data on save.");
                currentStoredUserStreams = []; // Reset if malformed
            }
        } catch (e) {
            console.error("Failed to parse existing streams from localStorage for saving, starting fresh.", e);
            currentStoredUserStreams = []; // Reset if error
        }
    }

    const streamIndex = currentStoredUserStreams.findIndex(s => s.id === editingStream.id);
    const updatedStream: Stream = {
        ...editingStream,
        name: editedName.trim(),
        sourceUrls: updatedSourceUrls,
        description: editedDescription.trim() || undefined,
        creatorId: editingStream.creatorId || userId, 
    };

    if (streamIndex > -1) {
        currentStoredUserStreams[streamIndex] = updatedStream;
    } else {
        // This should ideally not happen if editing existing streams from creator's list.
        // If it's an initial stream claimed, its creatorId would be set.
        currentStoredUserStreams.push(updatedStream);
    }

    updateLocalStorage(USER_ADDED_STREAMS_KEY, currentStoredUserStreams);
    loadStreamsFromLocalStorage(); 

    toast({ title: "Stream Updated", description: `${updatedStream.name} has been updated successfully.` });
    setIsEditDialogOpen(false);
    setEditingStream(null);
  };

  const handleRequestStreamDeletion = (streamToDelete: Stream) => {
    if (typeof window !== 'undefined') {
      const currentApprovedStreamsRaw = localStorage.getItem(USER_ADDED_STREAMS_KEY);
      let allApprovedStreams: Stream[] = [];
      if (currentApprovedStreamsRaw) {
        try { 
            const parsed = JSON.parse(currentApprovedStreamsRaw);
            if(Array.isArray(parsed)) allApprovedStreams = parsed;
        } catch (e) { console.error("Error parsing approved streams for deletion request:", e); }
      }
      const updatedAllApprovedStreams = allApprovedStreams.filter(s => s.id !== streamToDelete.id);
      updateLocalStorage(USER_ADDED_STREAMS_KEY, updatedAllApprovedStreams);

      setEditableStreams(prevStreams => prevStreams.filter(s => s.id !== streamToDelete.id));

      const pendingDeletionRaw = localStorage.getItem(STREAMS_PENDING_DELETION_KEY);
      let pendingDeletionStreams: Stream[] = [];
      if (pendingDeletionRaw) {
        try { 
            const parsed = JSON.parse(pendingDeletionRaw);
            if(Array.isArray(parsed)) pendingDeletionStreams = parsed;
        } catch (e) { console.error("Error parsing pending deletion streams:", e); }
      }
      if (!pendingDeletionStreams.find(s => s.id === streamToDelete.id)) {
        pendingDeletionStreams.push({ ...streamToDelete });
      }
      updateLocalStorage(STREAMS_PENDING_DELETION_KEY, pendingDeletionStreams);

      toast({
        title: "Deletion Requested",
        description: `Request to delete ${streamToDelete.name} has been sent to admin for approval.`,
      });
    }
  };

  const handleAddNewStreamSubmit = () => {
    if (!newStreamName.trim()) {
      toast({ title: "Validation Error", description: "Stream Name is required.", variant: "destructive" });
      return;
    }
    if (!validateUrlForForm(newStreamUrl1, "Primary HLS URL", true)) return;
    if (newStreamUrl2.trim() && !validateUrlForForm(newStreamUrl2, "Backup HLS URL 1")) return;
    if (newStreamUrl3.trim() && !validateUrlForForm(newStreamUrl3, "Backup HLS URL 2")) return;

    if (!userId) {
      toast({ title: "Authentication Error", description: "You must be logged in to submit a stream.", variant: "destructive" });
      return;
    }

    const sourceUrls = [newStreamUrl1.trim()];
    if (newStreamUrl2.trim()) sourceUrls.push(newStreamUrl2.trim());
    if (newStreamUrl3.trim()) sourceUrls.push(newStreamUrl3.trim());

    const newStream: Stream = {
      id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: newStreamName.trim(),
      sourceUrls: sourceUrls,
      description: newStreamDescription.trim() || undefined,
      views: 0,
      creatorId: userId,
    };

    if (typeof window !== 'undefined') {
        const pendingStreamsRaw = localStorage.getItem(PENDING_STREAMS_KEY);
        let pendingStreams: Stream[] = [];
        if (pendingStreamsRaw) {
            try {
                const parsed = JSON.parse(pendingStreamsRaw);
                if (Array.isArray(parsed)) pendingStreams = parsed;
            } catch (e) { console.error("Error parsing pending streams for new submission:", e); }
        }
        pendingStreams.push(newStream);
        localStorage.setItem(PENDING_STREAMS_KEY, JSON.stringify(pendingStreams));
        
        toast({ title: "Stream Submitted", description: `${newStream.name} has been submitted for approval. You can preview it now.` });
        setLastSubmittedStreamForPreview(newStream);
        setIsPreviewSubmittedStreamDialogOpen(true);
    }

    setNewStreamName('');
    setNewStreamUrl1('');
    setNewStreamUrl2('');
    setNewStreamUrl3('');
    setNewStreamDescription('');
  };

  const openPreviewDialog = (stream: Stream) => {
    setSelectedStreamForPreview(stream);
    setActivePreviewPlayingUrl(null);
    setIsPreviewDialogOpen(true);
  };

  const closePreviewDialog = () => {
    setIsPreviewDialogOpen(false);
    setSelectedStreamForPreview(null);
    setActivePreviewPlayingUrl(null);
  };


  if (!isClient || !isAuthenticated || userRole !== 'creator' || !userId) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
        <Card className="w-full max-w-2xl shadow-xl rounded-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center">
              You must be logged in as a creator to view this page. Redirecting to login...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center bg-background p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-4xl space-y-8">
        <Card className="shadow-xl rounded-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <UserCog className="w-8 h-8 text-primary" />
              <CardTitle className="text-3xl font-bold text-foreground">Creator Dashboard</CardTitle>
            </div>
            <div className="flex items-center gap-2">
                <Button variant="outline" asChild>
                <Link href="/" className="flex items-center gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Home
                </Link>
                </Button>
                <Button variant="ghost" onClick={logout} className="text-destructive-foreground hover:bg-destructive/10">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                </Button>
            </div>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-foreground">Manage Your Streams</CardTitle>
            <CardDescription>
              Edit, preview, or request deletion for streams you submitted. Deletion requires admin approval.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {editableStreams.length === 0 ? (
              <p className="text-muted-foreground">You have not submitted any streams, or none of your submissions have been approved yet. You can add new streams below.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-center">Views</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {editableStreams.map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">{stream.description || "N/A"}</TableCell>
                      <TableCell className="text-center text-sm text-muted-foreground">
                        <div className="flex items-center justify-center gap-1">
                           <Users className="w-4 h-4" />
                           {(stream.views || 0).toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openPreviewDialog(stream)}
                          aria-label={`Preview ${stream.name}`}
                        >
                          <Eye className="w-4 h-4 mr-1" /> Preview
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditStream(stream)}
                          aria-label={`Edit ${stream.name}`}
                        >
                          <Edit className="w-4 h-4 mr-1" /> Edit
                        </Button>
                         <Button
                          variant="ghost"
                          size="sm"
                          className="text-yellow-500 hover:text-yellow-600 hover:bg-yellow-500/10"
                          onClick={() => handleRequestStreamDeletion(stream)}
                          aria-label={`Request deletion for ${stream.name}`}
                        >
                          <Send className="w-4 h-4 mr-1" /> Request Deletion
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Add New Stream Section */}
        <Card className="shadow-md border border-border">
            <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2 text-foreground">
                <PlusCircle className="w-6 h-6 text-accent" />
                Add New HLS Stream (for Admin Approval)
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                Provide up to three HLS URLs (.m3u8) for a stream. The player will attempt to play them in order. Submitted streams require admin approval.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                <Label htmlFor="new-stream-name-creator" className="text-sm font-medium text-foreground">Stream Name</Label>
                <Input
                    id="new-stream-name-creator"
                    value={newStreamName}
                    onChange={(e) => setNewStreamName(e.target.value)}
                    placeholder="E.g., My Awesome Live Event"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url1-creator" className="text-sm font-medium text-foreground">Primary HLS URL (.m3u8)</Label>
                <Input
                    id="new-stream-url1-creator"
                    type="url"
                    value={newStreamUrl1}
                    onChange={(e) => setNewStreamUrl1(e.target.value)}
                    placeholder="https://example.com/live/stream1.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url2-creator" className="text-sm font-medium text-foreground">Backup HLS URL 1 (Optional)</Label>
                <Input
                    id="new-stream-url2-creator"
                    type="url"
                    value={newStreamUrl2}
                    onChange={(e) => setNewStreamUrl2(e.target.value)}
                    placeholder="https://backup.example.com/live/stream2.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-url3-creator" className="text-sm font-medium text-foreground">Backup HLS URL 2 (Optional)</Label>
                <Input
                    id="new-stream-url3-creator"
                    type="url"
                    value={newStreamUrl3}
                    onChange={(e) => setNewStreamUrl3(e.target.value)}
                    placeholder="https://another-backup.example.com/live/stream3.m3u8"
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                />
                </div>
                <div>
                <Label htmlFor="new-stream-description-creator" className="text-sm font-medium text-foreground">Description (Optional)</Label>
                <Textarea
                    id="new-stream-description-creator"
                    value={newStreamDescription}
                    onChange={(e) => setNewStreamDescription(e.target.value)}
                    placeholder="A brief description of the stream content."
                    className="mt-1 bg-input text-foreground border-border placeholder:text-muted-foreground"
                    rows={2}
                />
                </div>
                <Button onClick={handleAddNewStreamSubmit} className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90">
                <PlusCircle className="mr-2 h-4 w-4" /> Submit Stream for Approval
                </Button>
            </CardContent>
        </Card>

      </div>

      {/* Edit Stream Dialog */}
      {editingStream && (
        <Dialog open={isEditDialogOpen} onOpenChange={(isOpen) => {
          if (!isOpen) {
            setEditingStream(null);
          }
          setIsEditDialogOpen(isOpen);
        }}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit Stream: {editingStream.name}</DialogTitle>
              <DialogDescription>
                Update the details for your stream.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-stream-name" className="text-right col-span-1">Name</Label>
                <Input id="edit-stream-name" value={editedName} onChange={(e) => setEditedName(e.target.value)} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-stream-url1" className="text-right col-span-1">Primary URL</Label>
                <Input id="edit-stream-url1" type="url" value={editedUrl1} onChange={(e) => setEditedUrl1(e.target.value)} className="col-span-3" placeholder="https://example.com/stream1.m3u8" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-stream-url2" className="text-right col-span-1">Backup URL 1</Label>
                <Input id="edit-stream-url2" type="url" value={editedUrl2} onChange={(e) => setEditedUrl2(e.target.value)} className="col-span-3" placeholder="Optional: https://backup.com/stream2.m3u8" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-stream-url3" className="text-right col-span-1">Backup URL 2</Label>
                <Input id="edit-stream-url3" type="url" value={editedUrl3} onChange={(e) => setEditedUrl3(e.target.value)} className="col-span-3" placeholder="Optional: https://another.com/stream3.m3u8" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-stream-description" className="text-right col-span-1">Description</Label>
                <Textarea id="edit-stream-description" value={editedDescription} onChange={(e) => setEditedDescription(e.target.value)} className="col-span-3" placeholder="Optional: A brief description." />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancel</Button>
              </DialogClose>
              <Button type="button" onClick={handleSaveStream}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Preview Existing Stream Dialog */}
      {selectedStreamForPreview && (
        <Dialog open={isPreviewDialogOpen} onOpenChange={(isOpen) => {
          setIsPreviewDialogOpen(isOpen);
          if (!isOpen) {
            closePreviewDialog();
          }
        }}>
          <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px] w-full">
            <DialogHeader>
              <DialogTitle>Preview: {selectedStreamForPreview.name}</DialogTitle>
              {selectedStreamForPreview.description && (
                <DialogDescription>{selectedStreamForPreview.description}</DialogDescription>
              )}
            </DialogHeader>
            <div className="my-4 rounded-lg overflow-hidden">
              <HlsPlayer
                src={selectedStreamForPreview.sourceUrls}
                autoPlay={true}
                onActiveSourceChanged={setActivePreviewPlayingUrl}
              />
            </div>
            {activePreviewPlayingUrl && (
              <div className="mt-2 text-sm">
                <span className="font-medium text-foreground">Active Source: </span>
                <code className="text-xs bg-muted p-1 rounded-sm break-all text-muted-foreground">{activePreviewPlayingUrl}</code>
              </div>
            )}
            <DialogFooter className="mt-4">
              <Button type="button" variant="secondary" onClick={closePreviewDialog}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

       {/* Preview Newly Submitted Stream Dialog */}
      {lastSubmittedStreamForPreview && (
        <Dialog open={isPreviewSubmittedStreamDialogOpen} onOpenChange={setIsPreviewSubmittedStreamDialogOpen}>
          <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px] w-full">
            <DialogHeader>
              <DialogTitle>Previewing Your Submission: {lastSubmittedStreamForPreview.name}</DialogTitle>
              {lastSubmittedStreamForPreview.description && (
                <DialogDescription>{lastSubmittedStreamForPreview.description}</DialogDescription>
              )}
               <DialogDescription className="text-xs text-muted-foreground pt-1">
                This stream has been submitted for admin approval.
              </DialogDescription>
            </DialogHeader>
            <div className="my-4 rounded-lg overflow-hidden">
              <HlsPlayer src={lastSubmittedStreamForPreview.sourceUrls} autoPlay={true} />
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsPreviewSubmittedStreamDialogOpen(false)}>
                Close Preview
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </main>
  );
}


